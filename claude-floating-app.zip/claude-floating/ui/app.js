const $ = id => document.getElementById(id);
const login = $("login"), appView = $("app"), password = $("password");
const loginError = $("login-error"), chat = $("chat"), message = $("message");
let stream = null, history = [], sending = false, loginDebounce = null;

if (window.desktop) {
  $("minimize").onclick = () => window.desktop.minimize();
  $("close").onclick = () => window.desktop.close();
} else {
  $("minimize").style.display = "none"; $("close").style.display = "none";
}
password.addEventListener("input", async () => {
  loginError.textContent = "";
  clearTimeout(loginDebounce);
  if (password.value === "8815") {
    await loginNow();
  } else if (password.value.length > 0) {
    // Wait until typing pauses, so each character is not counted as a failed attempt.
    loginDebounce = setTimeout(() => loginNow(), 700);
  }
});
password.addEventListener("keydown", e => { if (e.key === "Enter") e.preventDefault(); });

async function loginNow() {
  if (password.disabled) return;
  password.disabled = true;
  try {
    const r = await fetch("/api/login", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:password.value})});
    const data = await r.json();
    if (!r.ok) {
      loginError.textContent = data.error || "Wrong password.";
      if (r.status === 429) password.disabled = true;
      else password.value = "";
      return;
    }
    login.classList.add("hidden"); appView.classList.remove("hidden");
    password.value = ""; history = [];
  } catch { loginError.textContent = "Could not connect. Try again."; }
  finally { if (!appView.classList.contains("hidden")) password.disabled = false; else if (!loginError.textContent.startsWith("Too many")) password.disabled = false; }
}
function addMessage(role, text) {
  const empty = chat.querySelector(".welcome"); if (empty) empty.remove();
  const el = document.createElement("div"); el.className = `message ${role}`;
  if (role === "assistant") {
    const label = document.createElement("div"); label.className = "label"; label.textContent = "CLAUDE"; el.appendChild(label);
  }
  const body = document.createElement("div"); body.textContent = text; el.appendChild(body);
  chat.appendChild(el); chat.scrollTop = chat.scrollHeight; return el;
}
async function getCurrentFrame() {
  if (!stream || !stream.getVideoTracks().some(t => t.readyState === "live")) return null;
  const video = document.createElement("video");
  video.srcObject = stream; video.muted = true; video.playsInline = true;
  await video.play();
  if (!video.videoWidth || !video.videoHeight) {
    await new Promise(resolve => video.onloadedmetadata = resolve);
  }
  const canvas = document.createElement("canvas");
  const scale = Math.min(1, 1280 / video.videoWidth);
  canvas.width = Math.round(video.videoWidth * scale);
  canvas.height = Math.round(video.videoHeight * scale);
  canvas.getContext("2d").drawImage(video, 0, 0, canvas.width, canvas.height);
  video.pause(); video.srcObject = null;
  const dataUrl = canvas.toDataURL("image/jpeg", 0.72);
  const [header, data] = dataUrl.split(",");
  return {mediaType:"image/jpeg", data};
}
$("share").onclick = async () => {
  try {
    stream = await navigator.mediaDevices.getDisplayMedia({video:{frameRate:5},audio:false});
    stream.getVideoTracks()[0].addEventListener("ended", stopSharing);
    $("screen-status").textContent = "Sharing is on";
    $("share").textContent = "Stop sharing";
    $("share").onclick = stopSharing;
    $("status").textContent = "Screen connected";
  } catch { $("status").textContent = "Screen sharing was not started"; }
};
function stopSharing() {
  if (stream) stream.getTracks().forEach(t => t.stop());
  stream = null;
  $("screen-status").textContent = "Not sharing";
  $("share").textContent = "Share my screen";
  $("share").onclick = startSharing;
  $("status").textContent = "Ready";
}
async function startSharing() {
  try {
    stream = await navigator.mediaDevices.getDisplayMedia({video:{frameRate:5},audio:false});
    stream.getVideoTracks()[0].addEventListener("ended", stopSharing);
    $("screen-status").textContent = "Sharing is on";
    $("share").textContent = "Stop sharing"; $("share").onclick = stopSharing;
    $("status").textContent = "Screen connected";
  } catch { $("status").textContent = "Screen sharing was not started"; }
}
async function sendMessage() {
  const q = message.value.trim();
  if (!q || sending) return;
  sending = true; $("send").disabled = true;
  addMessage("user", q); message.value = "";
  const placeholder = addMessage("assistant", "Thinking…");
  try {
    const image = await getCurrentFrame();
    const r = await fetch("/api/chat", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({question:q,history,image})});
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || "Request failed.");
    placeholder.lastChild.textContent = data.answer;
    history.push({role:"user",content:q},{role:"assistant",content:data.answer});
    history = history.slice(-20);
    $("status").textContent = image ? "Answered using current screen" : "Answered";
  } catch(e) { placeholder.lastChild.textContent = e.message || "Could not get an answer."; $("status").textContent = "Request failed"; }
  finally { sending = false; $("send").disabled = false; message.focus(); chat.scrollTop = chat.scrollHeight; }
}
$("send").onclick = sendMessage;
message.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});
$("logout").onclick = logout;
async function logout() {
  if (stream) stream.getTracks().forEach(t => t.stop());
  stream = null; history = []; chat.innerHTML = '<div class="welcome"><div class="welcome-mark">✳</div><h2>What can I help with?</h2><p>Share a screen to ask about what is on it.</p></div>';
  try { await fetch("/api/logout", {method:"POST",keepalive:true}); } catch {}
  appView.classList.add("hidden"); login.classList.remove("hidden"); password.value = ""; loginError.textContent = ""; password.disabled = false; password.focus();
}
window.addEventListener("beforeunload", () => {
  if (stream) stream.getTracks().forEach(t => t.stop());
  navigator.sendBeacon("/api/logout");
});
