require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const session = require("express-session");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");
const Anthropic = require("@anthropic-ai/sdk");

const app = express();
const PORT = Number(process.env.PORT || 8787);
const PASSWORD = process.env.APP_PASSWORD || "8815";
const SESSION_SECRET = process.env.SESSION_SECRET;
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-4-5";
const auditFile = path.join(__dirname, "signin-audit.jsonl");
const attempts = new Map();

if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error("Set SESSION_SECRET to a random string of at least 32 characters in .env");
  process.exit(1);
}
if (!process.env.ANTHROPIC_API_KEY) {
  console.warn("ANTHROPIC_API_KEY is missing. Chat will not work until you set it in .env.");
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "8mb" }));
app.use(session({
  name: "claude.sid",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "strict", secure: false, maxAge: 12 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "../ui")));

function clientIp(req) {
  // Do not trust forwarded IP headers unless behind a trusted proxy you control.
  return req.socket.remoteAddress || "unknown";
}
function audit(req, result) {
  const row = {
    time: new Date().toISOString(),
    ip: clientIp(req),
    device: String(req.get("user-agent") || "unknown").slice(0, 500),
    result
  };
  fs.appendFileSync(auditFile, JSON.stringify(row) + "\n", { mode: 0o600 });
}
function requireAuth(req, res, next) {
  if (req.session && req.session.authorized === true) return next();
  return res.status(401).json({ error: "Please sign in." });
}
const authLimiter = rateLimit({
  windowMs: 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false
});

app.get("/health", (_req, res) => res.json({ ok: true }));
app.get("/api/session", (req, res) => res.json({ authorized: req.session?.authorized === true }));

app.post("/api/login", authLimiter, async (req, res) => {
  const ip = clientIp(req);
  const now = Date.now();
  const state = attempts.get(ip) || { failures: [], lockedUntil: 0 };
  state.failures = state.failures.filter(t => now - t < 3 * 60 * 1000);
  if (state.lockedUntil > now) {
    const seconds = Math.ceil((state.lockedUntil - now) / 1000);
    attempts.set(ip, state);
    return res.status(429).json({ error: `Too many wrong passwords. Try again in ${Math.ceil(seconds / 60)} minutes.` });
  }
  const supplied = String(req.body?.password || "");
  // Constant-time-ish hash comparison avoids keeping password checks in client code.
  const expectedHash = await bcrypt.hash(PASSWORD, "$2a$10$abcdefghijklmnopqrstuu");
  const ok = supplied.length <= 256 && await bcrypt.compare(supplied, expectedHash);
  if (!ok) {
    state.failures.push(now);
    if (state.failures.length > 3) {
      state.lockedUntil = now + 10 * 60 * 1000;
      state.failures = [];
      attempts.set(ip, state);
      audit(req, "locked_out");
      return res.status(429).json({ error: "Too many wrong passwords. Access is locked for 10 minutes." });
    }
    attempts.set(ip, state);
    audit(req, "wrong_password");
    return res.status(401).json({ error: "Wrong password." });
  }
  state.failures = [];
  state.lockedUntil = 0;
  attempts.set(ip, state);
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start session." });
    req.session.authorized = true;
    req.session.save(err2 => {
      if (err2) return res.status(500).json({ error: "Could not start session." });
      audit(req, "success");
      res.json({ ok: true });
    });
  });
});
app.post("/api/logout", (req, res) => {
  if (req.session) {
    req.session.destroy(() => {
      res.clearCookie("claude.sid", { httpOnly: true, sameSite: "strict" });
      res.json({ ok: true });
    });
  } else res.json({ ok: true });
});

app.post("/api/chat", requireAuth, async (req, res) => {
  try {
    if (!process.env.ANTHROPIC_API_KEY) return res.status(503).json({ error: "Set ANTHROPIC_API_KEY in the private .env file first." });
    const question = String(req.body?.question || "").trim().slice(0, 6000);
    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-20) : [];
    const image = req.body?.image;
    if (!question) return res.status(400).json({ error: "Type a message first." });
    const messages = history.map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 6000)
    }));
    const content = [];
    if (image && typeof image.data === "string" && image.data.length < 7_000_000 &&
        ["image/jpeg", "image/png", "image/webp", "image/gif"].includes(image.mediaType)) {
      content.push({ type: "image", source: { type: "base64", media_type: image.mediaType, data: image.data } });
    }
    content.push({ type: "text", text: question });
    messages.push({ role: "user", content });
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const response = await client.messages.create({
      model: MODEL, max_tokens: 900,
      system: "You are Claude in a compact desktop helper. Answer the user's question directly first. Use the visible screen only when a screen image is provided. If this is schoolwork, explain clearly and give a useful answer. Do not claim to see anything that is not in the supplied image.",
      messages
    });
    res.json({ answer: response.content.filter(x => x.type === "text").map(x => x.text).join("\n") || "I couldn't form a text answer." });
  } catch (e) {
    console.error("Chat error:", e.message);
    res.status(500).json({ error: "The AI request failed. Check the API key, model name, and network connection." });
  }
});

app.listen(PORT, "127.0.0.1", () => console.log(`Claude Floating server at http://127.0.0.1:${PORT}`));
