# Claude Floating

A small Electron desktop window with a private Express backend, Claude vision chat, password gate, server-side failed-login lockout, and sign-in audit log.

## Setup

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Add your Anthropic API key to `ANTHROPIC_API_KEY`. Keep `.env` private.
4. Change `SESSION_SECRET` to a long random secret. Keep `APP_PASSWORD=8815` if you want the requested password.
5. Run:

   ```bash
   npm install
   npm start
   ```

6. Package it for your OS with `npm run build`.

## How screen context works

Click **Share my screen** once and select a screen or window. The app keeps the screen stream active. When you send a message, it takes one downscaled frame from that live stream and sends it with the question. This is needed because a vision model receives images, not a continuous live video feed. The app does not record or save video. Click **Stop sharing** to end capture.

## Security notes

- The password is checked by the server. The UI's instant auto-login is only a convenience, not the security boundary.
- Four wrong attempts within three minutes trigger a ten-minute lockout, keyed by the client's network IP. The lockout is enforced server-side, not by browser storage.
- Successful and failed sign-ins are written to `server/signin-audit.jsonl` with timestamp, remote IP, user-agent/device string, and result. Protect this file and rotate it as needed.
- The server binds to `127.0.0.1` so it is not exposed to the local network by default. If deployed publicly, use HTTPS, a persistent session store, a trusted proxy configuration, and a proper database-backed rate limit. Do not expose this development server directly to the internet.
- Session cookies are HTTP-only and same-site. The app sends a logout request when the window closes, but no browser can guarantee an unload event in every crash or forced termination. The session also expires after 12 hours. For strict immediate revocation, use a persistent server-side session store and a desktop shutdown handshake.
- The included audit log stores IP and device details, which are personal data. Tell users what you log and set a retention period before sharing the app.
- Never put the Anthropic key in `ui/` or any client-side code.
- This uses an Anthropic API key. A ChatGPT subscription cannot be used directly as an OpenAI API key. To use OpenAI instead, swap the server API client and configure an OpenAI API key.

## Limitations

This is a working project scaffold, not an installed app or a hosted public service. You must add your API key and run/package it locally. It cannot sign users in with their existing ChatGPT account without building a separate supported OAuth integration.
