const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("desktop", {
  minimize: () => ipcRenderer.invoke("app:minimize"),
  close: () => ipcRenderer.invoke("app:close")
});
