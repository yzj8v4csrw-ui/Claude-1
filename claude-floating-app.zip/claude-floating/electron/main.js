const { app, BrowserWindow, ipcMain, session } = require("electron");
const path = require("path");

let win;
function createWindow() {
  win = new BrowserWindow({
    width: 390, height: 720, minWidth: 330, minHeight: 480,
    title: "Claude",
    alwaysOnTop: true,
    autoHideMenuBar: true,
    backgroundColor: "#111111",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadURL("http://127.0.0.1:8787");
  win.on("closed", () => { win = null; });
}
app.whenReady().then(() => {
  session.defaultSession.setPermissionRequestHandler((wc, permission, callback) => {
    callback(permission === "media");
  });
  ipcMain.handle("app:minimize", () => win?.minimize());
  ipcMain.handle("app:close", () => win?.close());
  createWindow();
});
app.on("window-all-closed", () => app.quit());
